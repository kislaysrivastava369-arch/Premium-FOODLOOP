# FoodLoop – Final Teacher Demo (classroom prototype)

Open `index.html` in Chrome. No build step, no API keys. Needs internet for map tiles, fonts and icons (CDN).

## What the teacher should see (home page)
1. **Who Are You?** – three cards: NGO, Food Assistance, General Individual (each opens a working form).
2. **Verify first → Allocate → Pay last** – the six-step flow, plus the NGO path
   *NGO Registration → Document Review → Admin Approval → Verified NGO Badge → Priority Allocation → Free Pickup*.
3. **Two feature panels** – "Verified People. Fair Food Distribution." and "First We Allocate Fairly. Then You Pay Only If Required."
4. **See How FoodLoop Gives Food Fairly** – *Run the 50-Meal Priority Demo* (NGO 30 free, A 15, B 5, C 0) and *Verified Needy Recipient vs Ordinary Buyer*. Both call the same allocation function the site uses.

## Fictional demo logins (password in brackets)
| Account | Email | Password |
|---|---|---|
| Demo admin | admin@foodloop.demo | Admin@1234 |
| Verified NGO | ngo@annadaan.demo | Demo@1234 |
| Pending NGO | hope@hopekitchen.demo | Demo@1234 |
| Rejected NGO | shelter@oldtrust.demo | Demo@1234 |
| Verified assistance recipient | asha@demo.test | Demo@1234 |
| General individual | ravi@demo.test | Demo@1234 |

## Walk-throughs
- **Register an NGO:** home → "Register my NGO". Use fictional values (registration no. like `DEMO-REG-4004`; Darpan, PAN and GSTIN are optional; GSTIN only if you tick GST-registered). Result: *NGO Application Submitted — Verification Pending.* It gets no priority.
- **Approve it:** click the account chip → log in as admin → Dashboards → Admin → NGO applications → Approve. The NGO is now *Verified NGO — Priority Enabled*.
- **Assistance recipient:** home → "Request assistance". No ID upload. Status stays Pending until admin approves. Only the user and admin see it.
- **Priority window demo (live):** Discover → "Restaurant surplus: 50 meals" has queued sample requests and a 30-minute NGO window. Log in as the verified NGO and request 30. Nothing is final and nobody can pay. Admin → "Advance 30 min" closes the window, allocations become final, free pickups get codes, payments open only where an amount is due.
- **Policy switch:** Admin → Allocation policy: *NGO → assistance → general* or the simpler *NGOs first → all individuals FCFS*. The active policy is shown on the home page.
- **Payments:** an allocated general individual clicks Pay now → UPI (Google Pay/PhonePe/Paytm/Other), Card, Net Banking or Wallet → Simulate Payment (choose success or failure) → order ID, receipt, pickup code. Cancelling after payment creates a refund record and releases the servings.
- **Reset:** Admin → Reset demo data.

## Tests
`npm i jsdom` then `node tests/test.js` runs 35 checks on the real `app.js` (allocation, verification, windows, payments, refunds, pickup, rendering).

## Everything here is a simulation
Verification, admin login, payments, refunds, notifications, calls/SMS and the certificate upload are browser-only. Passwords you register are kept in memory only (cleared on refresh); demo passwords above are fictional. Use fictional identifiers only. FoodLoop's priority rule is a configurable proposed policy, not a government poverty determination.

## Needed before real deployment
Server-side authentication and authorization; encrypted document storage and review workflow; audit logs; privacy-compliant assistance eligibility process (legal review); database with transactional allocation; an authorized payment gateway (e.g. Razorpay) with server-side order creation, signature verification, webhooks, idempotency keys and secure refunds; real email/SMS notifications.
