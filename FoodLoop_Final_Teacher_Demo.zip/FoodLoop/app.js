/* FoodLoop – vanilla JS prototype. All data lives in this browser's localStorage (demo only). */
(() => {
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const IC = (n, s = 16) => `<i data-lucide="${n}" style="width:${s}px;height:${s}px"></i>`;
const icons = () => window.lucide && lucide.createIcons();

const KEY = 'foodloop.v1';
const ORIGIN = { lat: 12.9716, lng: 77.5946 };           // demo start point (campus gate), not GPS
const KG_PER_SERVING = 0.4;
const CATS = { 'Cooked Meals':'🍛','Bakery':'🥖','Fruits & Vegetables':'🍅','Packaged Food':'📦','Event Surplus':'🎪','Other Edible Food':'🍱' };
const ST = { available:'Available', pending:'Request pending', accepted:'Accepted – ready to collect', completed:'Completed', allocated:'Fully allocated', cancelled:'Cancelled', expired:'Expired' };
const stCls = s => ({available:'status-available',pending:'status-pending',accepted:'status-pending',completed:'status-done',allocated:'status-done'}[s] || 'status-bad');
const H = h => new Date(Date.now() + h * 36e5).toISOString();
const RECIPIENT_CAPACITY = 60; // demo pickup capacity in servings

/* ---------- Data layer ---------- */
function seed() {
  const L = (id, title, cat, diet, servings, allergens, org, made, dl, dx, dy, address, handling, desc) =>
    ({ id, title, cat, diet, servings, allergens, org, made: H(made), deadline: H(dl), lat: ORIGIN.lat + dx, lng: ORIGIN.lng + dy,
       address, handling, desc, phone: '9800000000', status: 'available', code: null, sample: true });
  return {
    listings: [
      L('l1','Vegetable pulao','Cooked Meals','veg',60,'','Campus Canteen',-1.5,3,.004,.006,'Main Canteen, College Campus, Bengaluru','Keep hot. Eat within 3 hours.','Freshly cooked pulao in covered steel containers.'),
      L('l2','Chicken curry and rice','Cooked Meals','nonveg',40,'','Hostel Mess B',-1,2,-.005,.004,'Hostel Block B Mess, College Campus, Bengaluru','Keep hot. Do not refrigerate and reheat twice.','Dinner leftovers from the evening batch.'),
      L('l3','Fresh bread loaves','Bakery','veg',30,'Gluten, milk','Sunrise Bakery',-4,6,.008,-.006,'Sunrise Bakery, MG Road, Bengaluru','Store dry at room temperature.','Unsold loaves from today, packed in paper bags.'),
      L('l4','Seasonal fruit boxes','Fruits & Vegetables','veg',25,'','GreenMart Grocers',-5,20,-.009,-.007,'GreenMart, Indiranagar, Bengaluru','Keep cool and out of the sun.','Slightly bruised but good fruit, ready to eat today.'),
      L('l5','Fest snack packs','Event Surplus','veg',120,'Nuts','Cultural Fest Team',-2,1.2,.002,-.009,'Open Air Theatre, College Campus, Bengaluru','Sealed packs. Keep dry.','Sealed snack packs left after the cultural fest.'),
      L('l6','Biscuits and juice cartons','Packaged Food','veg',80,'Gluten','City Food Mart',-24,48,-.003,.011,'City Food Mart, Koramangala, Bengaluru','Sealed. Check expiry on pack.','Sealed packets nearing their best-before date.')
    ],
    orgs: [
      { id:'o1', name:'Campus Canteen', type:'Food donor', status:'verified' },
      { id:'o2', name:'Hostel Mess B', type:'Food donor', status:'verified' },
      { id:'o3', name:'Cultural Fest Team', type:'Food donor', status:'verified' },
      { id:'o4', name:'Sunrise Bakery', type:'Food donor', status:'pending' },
      { id:'o5', name:'GreenMart Grocers', type:'Food donor', status:'pending' },
      { id:'o6', name:'Hope Community Kitchen', type:'NGO / community kitchen', status:'pending' }
    ],
    done: [
      { title:'Bread and buns', cat:'Bakery', servings:30, at:H(-72), sample:true },
      { title:'Veg biryani', cat:'Cooked Meals', servings:50, at:H(-48), sample:true },
      { title:'Fruit crates', cat:'Fruits & Vegetables', servings:20, at:H(-26), sample:true }
    ],
    log: [{ t: H(-1), m: 'Demo data loaded' }],
    my: null
  };
}
let S;
try { S = JSON.parse(localStorage.getItem(KEY)); } catch (e) { S = null; }
if (!S || !S.listings) S = seed();
const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} };
const log = m => { S.log.unshift({ t: new Date().toISOString(), m }); S.log = S.log.slice(0, 30); };
const byId = id => S.listings.find(l => l.id === id);
const isVerified = name => S.orgs.some(o => o.name.toLowerCase() === String(name).toLowerCase() && o.status === 'verified');

/* ---------- Core v3: accounts, verification, priority engine, payments-after-allocation (no DOM) ---------- */
let curId = null;
function now() { return Date.now() + ((S && S.off) || 0); }       // demo clock (Advance Demo Time)
const code = () => String(1000 + Math.floor(Math.random() * 9000));
const uid = p => p + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const PAY = { not_required:'FREE — no payment required', awaiting_allocation:'Payment opens after allocation', pending:'Payment due', successful:'Paid (simulated)', failed:'Failed (simulated)', refunded:'Refunded (simulated)' };
const RS = { queued:'Queued (priority window open)', allocated:'Allocated', confirmed:'Confirmed', unallocated:'Waitlisted – 0 servings', cancelled:'Cancelled' };
const PK = { not_collected:'Not collected', collected:'Collected' };
const OPEN = ['queued', 'allocated', 'confirmed'];
/* Demo-only credentials (fictional). Registered passwords stay in memory and are never written to localStorage. */
const DEMO_PW = { 'ngo@annadaan.demo':'Demo@1234', 'hope@hopekitchen.demo':'Demo@1234', 'shelter@oldtrust.demo':'Demo@1234', 'asha@demo.test':'Demo@1234', 'ravi@demo.test':'Demo@1234', 'admin@foodloop.demo':'Admin@1234' };
const PWD = {};
const meAcc = () => (S.acc || []).find(a => a.id === S.session) || null;
/* Priority comes ONLY from admin-set status on the logged-in account. Names/dropdowns never matter. */
const tierOfAcc = a => !a ? 3 : (a.role === 'ngo' && a.status === 'verified') ? 1 : (a.role === 'assist' && a.status === 'verified') ? 2 : 3;
function statusLabel(a) {
  if (a.role === 'ngo') return { verified:'Verified NGO — Priority Enabled', pending:'Verification Pending', rejected:'Rejected — Contact Administrator' }[a.status];
  if (a.role === 'assist') return { verified:'Verified for Assistance', pending:'Assistance Review Pending', rejected:'Not Verified' }[a.status];
  return a.role === 'admin' ? 'Demo Admin' : 'Individual';
}
const lres = l => S.res.filter(r => r.lid === l.id);
const committed = l => lres(l).filter(r => ['allocated', 'confirmed'].includes(r.rs)).reduce((a, r) => a + r.alloc, 0);
const remaining = l => Math.max(0, l.servings - committed(l));
const windowOpen = l => now() < (l.windowEnd || 0);
const eff = l => l.status === 'cancelled' ? 'cancelled' : (now() > new Date(l.deadline) && remaining(l) > 0) ? 'expired' : remaining(l) === 0 ? 'allocated' : 'available';
const curTier = r => { const a = r.acc && S.acc.find(x => x.id === r.acc); return a ? tierOfAcc(a) : r.tier; };
/*ALLOC-START*/
/* policy 'fair3': NGO > verified assistance > general. policy 'simple': NGO > everyone else FCFS. FCFS inside each group. */
function allocateQueue(total, lockedQty, reqs, policy) {
  const tr = r => r.tier === 1 ? 1 : (policy === 'simple' ? 3 : r.tier);
  let rem = Math.max(0, total - lockedQty);
  return [...reqs].sort((a, b) => tr(a) - tr(b) || a.ts - b.ts).map(r => { const a = Math.min(r.requested, rem); rem -= a; return { r, a }; });
}
/*ALLOC-END*/
const unitPrice = (l, tier) => tier === 1 ? 0 : tier === 2 ? l.assistPrice : l.price;
function finalizeRes(r, l, a) {
  r.tier = curTier(r); r.type = r.tier === 1 ? 'ngo' : r.tier === 2 ? 'assist' : 'individual'; r.alloc = a;
  r.unit = unitPrice(l, r.tier); r.amount = a * r.unit;
  if (a === 0) { r.rs = 'unallocated'; r.pay = 'not_required'; }
  else if (r.amount === 0) { r.rs = 'confirmed'; r.pay = 'not_required'; r.code = r.code || code(); }
  else { r.rs = 'allocated'; r.pay = 'pending'; }
}
function provisional(l) { allocateQueue(l.servings, committed(l), lres(l).filter(r => r.rs === 'queued').map(r => (r.tier = curTier(r), r)), S.policy).forEach(({ r, a }) => r.alloc = a); }
/* Closes the NGO-priority window: allocations become final; committed ones are never revoked afterwards. */
function finalizeDue() {
  let n = 0;
  S.listings.forEach(l => {
    const q = lres(l).filter(r => r.rs === 'queued'); if (windowOpen(l) || !q.length) return;
    allocateQueue(l.servings, committed(l), q.map(r => (r.tier = curTier(r), r)), S.policy).forEach(({ r, a }) => { finalizeRes(r, l, a); n++; });
    log(`Priority window closed for “${l.title}”: allocations finalised (policy ${S.policy === 'simple' ? 'NGOs first, then all individuals FCFS' : 'NGO > assistance > general'})`);
  });
  if (n) save(); return n;
}
function advanceTime(min) { S.off = (S.off || 0) + min * 6e4; const n = finalizeDue(); S.listings.forEach(provisional); save(); return n; }
function createRequest(lid, accId, qty, ts = now()) {
  finalizeDue();
  const l = byId(lid); if (!l) return { ok: false, msg: 'Listing not found.' };
  if (l.status === 'cancelled' || now() > new Date(l.deadline)) return { ok: false, msg: 'This food has expired or been withdrawn.' };
  const a = S.acc.find(x => x.id === accId) || null, q = Math.floor(+qty);
  if (!(q >= 1 && q <= 2000)) return { ok: false, msg: 'Enter a quantity of at least 1.' };
  if (l.servings - committed(l) < 1) return { ok: false, msg: 'No uncommitted servings left.' };
  const key = a ? a.id : 'guest';
  if (lres(l).some(r => r.key === key && OPEN.includes(r.rs) && r.pickup !== 'collected')) return { ok: false, msg: 'You already have an open request for this food.' };
  const tier = tierOfAcc(a);
  const r = { id: uid('r'), lid, key, acc: a ? a.id : null, who: a ? a.name : 'Guest', tier, type: tier === 1 ? 'ngo' : tier === 2 ? 'assist' : 'individual', requested: q, alloc: 0, ts, rs: 'queued', pay: 'awaiting_allocation', pickup: 'not_collected', code: null, amount: 0, mine: true };
  S.res.push(r);
  if (windowOpen(l)) provisional(l);                       // queued; nothing is final yet
  else finalizeRes(r, l, Math.min(q, l.servings - committed(l))); // late request: only uncommitted servings
  log(`${r.who} requested ${q} of “${l.title}” (tier ${tier})`); save();
  return { ok: true, res: r };
}
/* Payment is possible ONLY for finalised allocations with an amount due. Simulated; stores no card/UPI details. */
function payRes(rid, method, outcome, sub) {
  const r = S.res.find(x => x.id === rid);
  if (!r || r.rs !== 'allocated' || !(r.amount > 0) || !['pending', 'failed'].includes(r.pay)) return { ok: false, msg: 'Payment is available only after your allocation is final and an amount is due.' };
  const ok = outcome === 'success', order = 'ORD-' + Date.now().toString(36).toUpperCase();
  S.pay.unshift({ id: uid('p'), order, rid, amount: r.amount, method, sub: sub || '', status: ok ? 'successful' : 'failed', ts: new Date().toISOString(), demo: true });
  if (ok) { r.pay = 'successful'; r.rs = 'confirmed'; r.code = code(); r.order = order; } else r.pay = 'failed';
  log(`Demo payment ${ok ? 'succeeded' : 'failed'}: ₹${r.amount} (${method})`); save();
  return { ok, res: r, amount: r.amount, order };
}
function cancelRes(rid) {
  const r = S.res.find(x => x.id === rid);
  if (!r || !OPEN.includes(r.rs) || r.pickup === 'collected') return { ok: false };
  if (r.pay === 'successful') { S.pay.unshift({ id: uid('p'), order: r.order, rid, amount: r.amount, method: '—', status: 'refunded', ts: new Date().toISOString(), demo: true }); r.pay = 'refunded'; }
  r.rs = 'cancelled'; r.note = 'Cancelled before pickup'; provisional(byId(r.lid)); save(); return { ok: true };
}
function collectRes(rid) {
  const r = S.res.find(x => x.id === rid);
  if (!r || r.rs !== 'confirmed' || r.pickup !== 'not_collected') return { ok: false, msg: 'This reservation cannot be collected (already collected or not confirmed).' };
  const l = byId(r.lid); r.pickup = 'collected';
  S.done.unshift({ title: l.title, cat: l.cat, servings: r.alloc, at: new Date().toISOString(), sample: false, rid });
  log(`Collected: ${r.alloc} of “${l.title}” by ${r.who}`); save(); return { ok: true, res: r, l };
}
/* ---- accounts (no passwords persisted; fictional identifiers only) ---- */
function register(role, v) {
  const e = {}, em = (v.email || '').toLowerCase();
  if (!v.name) e.name = role === 'ngo' ? 'Enter the NGO name.' : 'Enter a name.';
  if (role === 'ngo' || !v.phone || v.email) if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em) && (role === 'ngo' || v.email)) e.email = 'Enter a valid email.';
  if (role !== 'ngo' && !v.email && !/^\d{10}$/.test(v.phone || '')) e.email = 'Enter an email or a 10-digit phone.';
  if ((v.pw || '').length < 8) e.pw = 'Use at least 8 characters.';
  if (v.pw !== v.pw2) e.pw2 = 'Passwords do not match.';
  if (!v.city && role !== 'ngo') e.city = 'Enter your city or area.';
  if (role === 'ngo') {
    if (!v.contact) e.contact = 'Enter the contact person’s name.';
    if (!/^\d{10}$/.test(v.phone || '')) e.phone = 'Enter a 10-digit contact number.';
    if (!v.address) e.address = 'Enter the organisation address.';
    if (!/^[A-Z0-9\/-]{5,}$/i.test(v.regNo || '')) e.regNo = 'Enter the (fictional) registration/certificate number.';
    if (v.darpan && !/^[A-Z]{2}\/\d{4}\/\d{7}$/i.test(v.darpan)) e.darpan = 'Format like DL/2020/0123456.';
    if (v.pan && !/^[A-Z]{5}\d{4}[A-Z]$/i.test(v.pan)) e.pan = 'Format like ABCDE1234F (fictional).';
    if (v.gst && !/^\d{2}[A-Z]{5}\d{4}[A-Z][A-Z\d]Z[A-Z\d]$/i.test(v.gstin || '')) e.gstin = 'Enter a valid GSTIN format (fictional).';
    if (!v.cert) e.cert = 'Tick to attach the demo certificate (simulated, nothing is uploaded).';
  }
  const key = em || v.phone;
  if (!e.email && S.acc.some(a => a.email === key)) e.email = 'An account with this email/phone already exists.';
  if (Object.keys(e).length) return { ok: false, errors: e };
  const a = { id: uid('a'), role, name: v.name, email: key, city: v.city || '', status: role === 'general' ? 'active' : 'pending', submittedAt: new Date().toISOString(),
    ...(role === 'ngo' ? { contact: v.contact, phone: v.phone, address: v.address, regNo: v.regNo, darpan: v.darpan || '', pan: v.pan || '', gstin: v.gst ? v.gstin : '' } : {}),
    ...(role === 'assist' ? { family: v.family || '', note: v.note || '' } : {}) };
  S.acc.push(a); PWD[key] = v.pw; S.session = a.id; log(`${role} account registered: ${a.name} (${a.status})`); save();
  return { ok: true, acc: a };
}
function login(email, pw) {
  const a = S.acc.find(x => x.email === (email || '').toLowerCase());
  if (!a || !((DEMO_PW[a.email] && DEMO_PW[a.email] === pw) || (PWD[a.email] && PWD[a.email] === pw))) return { ok: false, msg: 'Wrong email/phone or password. (Passwords of accounts you registered are kept only in memory and are cleared on refresh.)' };
  S.session = a.id; save(); return { ok: true, acc: a };
}
function review(accId, verdict) { const a = S.acc.find(x => x.id === accId), m = meAcc(); if (!a || !m || m.role !== 'admin') return false; a.status = verdict; log(`Admin ${verdict}: ${a.name}`); save(); return true; }
const seedAcc = () => { const t = new Date().toISOString(), A = (id, role, name, email, status, x = {}) => ({ id, role, name, email, city: 'Bengaluru', status, submittedAt: t, ...x });
  return [A('a1', 'ngo', 'Annadaan NGO (demo)', 'ngo@annadaan.demo', 'verified', { regNo: 'DEMO-REG-1001', darpan: 'KA/2020/0123456', pan: 'ABCDE1234F', gstin: '', contact: 'Demo Contact', phone: '9000000001', address: 'Demo Street, Bengaluru' }),
    A('a2', 'ngo', 'Hope Community Kitchen (demo)', 'hope@hopekitchen.demo', 'pending', { regNo: 'DEMO-REG-2002', darpan: '', pan: '', gstin: '', contact: 'Demo Contact', phone: '9000000002', address: 'Demo Lane, Bengaluru' }),
    A('a3', 'ngo', 'Old Shelter Trust (demo)', 'shelter@oldtrust.demo', 'rejected', { regNo: 'DEMO-REG-3003', darpan: '', pan: '', gstin: '', contact: 'Demo Contact', phone: '9000000003', address: 'Demo Road, Bengaluru' }),
    A('a4', 'assist', 'Asha (demo assistance recipient)', 'asha@demo.test', 'verified', { family: '4', note: 'Fictional demo profile' }),
    A('a5', 'general', 'Ravi (demo individual)', 'ravi@demo.test', 'active'), A('a6', 'admin', 'FoodLoop Demo Admin', 'admin@foodloop.demo', 'active')]; };
const fifty = () => { const t = Date.now(), I = h => new Date(t + h * 36e5).toISOString(), P = (id, who, q, m) => ({ id, lid: 'l50', key: id, acc: null, who, tier: 3, type: 'individual', requested: q, alloc: q, ts: t - m * 6e4, rs: 'queued', pay: 'awaiting_allocation', pickup: 'not_collected', code: null, amount: 0, mine: false });
  return { l: { id: 'l50', title: 'Restaurant surplus: 50 meals', cat: 'Cooked Meals', diet: 'veg', servings: 50, allergens: '', org: 'Green Leaf Restaurant (demo)', made: I(-1), deadline: I(6), lat: ORIGIN.lat + .003, lng: ORIGIN.lng - .004, address: 'Green Leaf Restaurant, Indiranagar, Bengaluru', handling: 'Keep hot.', desc: 'Sample 50-meal donation used for the priority demo.', phone: '9800000000', status: 'available', price: 5, assistPrice: 0, windowEnd: t + 30 * 6e4, sample: true },
    r: [P('rdA', 'Person A (sample)', 15, 20), P('rdB', 'Person B (sample)', 10, 19), P('rdC', 'Person C (sample)', 10, 15)] }; };
function migrate() {
  S.res = Array.isArray(S.res) ? S.res : []; S.pay = Array.isArray(S.pay) ? S.pay : []; S.done = S.done || []; S.orgs = S.orgs || []; S.log = S.log || [];
  S.off = S.off || 0; S.policy = S.policy || 'fair3'; S.windowMin = S.windowMin || 30;
  if (!Array.isArray(S.acc) || !S.acc.length) S.acc = seedAcc();
  S.listings.forEach(l => {
    l.servings = Math.max(1, +l.servings || 1); if (typeof l.price !== 'number') l.price = 5;
    if (typeof l.assistPrice !== 'number') l.assistPrice = 0; if (typeof l.windowEnd !== 'number') l.windowEnd = 0;
    if (['pending', 'accepted', 'completed'].includes(l.status)) {
      S.res.push({ id: 'r' + l.id, lid: l.id, key: 'legacy', who: 'Earlier recipient', tier: 3, type: 'individual', requested: l.servings, alloc: l.servings, ts: Date.now(), rs: 'confirmed', pay: 'successful', pickup: l.status === 'completed' ? 'collected' : 'not_collected', code: l.code || '0000', amount: 0, mine: false });
      l.status = 'available';
    }
  });
  S.res.forEach(r => { if (r.rs === 'pending') r.rs = r.type === 'ngo' ? 'confirmed' : 'allocated'; if (!r.tier) r.tier = r.type === 'ngo' ? 1 : 3; if (!r.key) r.key = r.as || 'legacy'; });
  if (!S.listings.some(l => l.id === 'l50')) { const f = fifty(); S.listings.unshift(f.l); S.res.push(...f.r); }
  delete S.my; S.v = 3;
}
function extraStats() {
  const act = S.listings.filter(l => l.status !== 'cancelled'), conf = S.res.filter(r => r.rs === 'confirmed'), sum = a => a.reduce((x, r) => x + r.alloc, 0);
  return [['Total food listed (servings)', act.reduce((a, l) => a + l.servings, 0)], ['Reserved by verified NGOs (free)', sum(conf.filter(r => r.tier === 1))],
    ['Assistance recipients', sum(conf.filter(r => r.tier === 2))], ['Purchased by general individuals', sum(conf.filter(r => r.tier === 3))],
    ['Collected (confirmed pickups)', sum(conf.filter(r => r.pickup === 'collected'))], ['Verified NGOs', S.acc.filter(a => a.role === 'ngo' && a.status === 'verified').length],
    ['Simulated payments', '₹' + S.pay.filter(p => p.status === 'successful').reduce((a, p) => a + p.amount, 0)]]
    .map(([k, n]) => `<div class="stat"><b>${typeof n === 'number' ? n.toLocaleString() : n}</b><span>${k}</span></div>`).join('');
}
const rBadge = r => `<span class="badge ${r.pay === 'not_required' ? 'verified' : r.pay === 'successful' ? 'status-available' : 'status-pending'}">${PAY[r.pay]}</span>`;
const rAct = r => !r.mine ? '' : [
  r.rs === 'allocated' && r.amount > 0 && ['pending', 'failed'].includes(r.pay) ? `<button class="btn btn-primary" data-act="pay" data-rid="${r.id}">Pay now</button>` : '',
  r.rs === 'confirmed' && r.pickup === 'not_collected' ? `<button class="btn btn-primary" data-act="collect" data-rid="${r.id}">I collected</button>` : '',
  OPEN.includes(r.rs) && r.pickup !== 'collected' ? `<button class="btn btn-ghost" data-act="rcancel" data-rid="${r.id}">Cancel</button>` : ''].join('');
const pubType = (r, adm) => r.type === 'ngo' ? 'Verified NGO' : (r.type === 'assist' && (adm || r.mine)) ? 'Assistance recipient' : 'Individual';
const resRows = (rs, food, adm) => rs.map(r => `<tr>${food ? `<td>${esc((byId(r.lid) || {}).title)}</td>` : ''}<td>${esc(r.who)}<br><small>${pubType(r, adm)}</small></td>
  <td>${r.rs === 'queued' ? `<em>${r.alloc}</em> of ${r.requested} (provisional)` : `${r.alloc}${r.requested !== r.alloc ? ` of ${r.requested}` : ''}`}</td><td>${rBadge(r)}${r.rs !== 'queued' && r.alloc ? `<br><small>₹${r.amount}${r.unit !== undefined ? ` @ ₹${r.unit}` : ''}</small>` : ''}</td>
  <td>${RS[r.rs]} • ${PK[r.pickup]}${r.note ? `<br><small>${esc(r.note)}</small>` : ''}</td><td>${r.code && r.rs === 'confirmed' ? r.code : '–'}</td><td>${rAct(r)}</td></tr>`).join('') || '<tr><td colspan="7">None yet.</td></tr>';
const RH = f => [...(f ? ['Food'] : []), 'Recipient', 'Servings', 'Payment', 'Status', 'Code', 'Actions'];


/* ---------- Helpers ---------- */
let me = null; // user location (only after consent)
const origin = () => me || ORIGIN;
const rad = x => x * Math.PI / 180;
function km(a, b) {
  const dLat = rad(b.lat - a.lat), dLng = rad(b.lng - a.lng);
  const h = Math.sin(dLat/2)**2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng/2)**2;
  return 12742 * Math.asin(Math.sqrt(h));
}
const dist = l => km(origin(), l);
const fmtT = iso => {
  const d = new Date(iso), t = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  return d.toDateString() === new Date().toDateString() ? t : d.toLocaleDateString([], { weekday: 'short' }) + ' ' + t;
};
const freshText = l => `${l.cat === 'Cooked Meals' ? 'Cooked' : 'Ready'} at ${fmtT(l.made)} • Collect before ${fmtT(l.deadline)}`;
const soon = l => { const m = (new Date(l.deadline) - Date.now()) / 6e4; return m > 0 && m < 90; };
const walkMins = l => Math.max(1, Math.round(dist(l) / 5 * 60));
const dirURL = l => 'https://www.google.com/maps/dir/?api=1&destination=' + encodeURIComponent(l.address) + '&travelmode=walking' + (me ? `&origin=${me.lat},${me.lng}` : '');

function toast(msg, type = 'ok') {
  const t = document.createElement('div');
  t.className = 'toast ' + type;
  t.innerHTML = (type === 'ok' ? IC('check-circle', 20) : IC('alert-circle', 20)) + '<span>' + esc(msg) + '</span>';
  $('#toasts').appendChild(t); icons();
  setTimeout(() => t.remove(), 3100);
}
function countUp(el) {
  const n = +el.dataset.count, reduce = matchMedia('(prefers-reduced-motion:reduce)').matches;
  if (reduce || n === 0) { el.textContent = n.toLocaleString(); return; }
  const t0 = performance.now();
  (function f(t) { const p = Math.min(1, (t - t0) / 1100); el.textContent = Math.round(n * (1 - (1 - p) ** 3)).toLocaleString(); if (p < 1) requestAnimationFrame(f); })(t0);
}

/* ---------- Impact ---------- */
function impact() {
  const sv = S.done.reduce((a, x) => a + x.servings, 0);
  return { count: S.done.length, servings: sv, kg: Math.round(sv * KG_PER_SERVING), orgs: S.orgs.filter(o => o.status === 'verified').length,
           sample: S.done.filter(x => x.sample).length };
}
const statsHTML = i => [
  ['Donations completed', i.count], ['Estimated servings redistributed', i.servings],
  ['Estimated food weight (kg)', i.kg], ['Verified organisations', i.orgs]
].map(([l, n]) => `<div class="stat"><b data-count="${n}">0</b><span>${l}</span></div>`).join('');

/* ---------- Cards ---------- */
function cardHTML(l) {
  const st = eff(l), v = isVerified(l.org);
  return `<article class="card"><div class="card-img" aria-hidden="true">${CATS[l.cat] || '🍱'}</div><div class="card-body">
    <div class="badges">
      <span class="badge"><span class="vd ${l.diet}"></span>${l.diet === 'veg' ? 'Veg' : 'Non-veg'}</span>
      ${l.allergens ? `<span class="badge allergen">${IC('alert-triangle')}Contains: ${esc(l.allergens)}</span>` : ''}
      <span class="badge ${stCls(st)}">${ST[st]}</span>
    </div>
    <h3>${esc(l.title)}</h3>
    <p class="meta">${esc(l.org)} ${v ? `<span class="badge verified">${IC('shield-check')}Verified</span>` : ''}</p>
    <div class="fresh ${soon(l) ? 'soon' : ''}">${IC('clock', 18)}<span>${freshText(l)}</span></div>
    <p class="meta">${remaining(l)} of ${l.servings} servings left • ${l.price ? '₹' + l.price + ' each (NGOs free)' : 'Free'} • ${dist(l).toFixed(1)} km away${me ? '' : ' (from demo start)'}</p>
    <button class="btn btn-primary" data-open="${l.id}">View details</button>
  </div></article>`;
}

/* ---------- Router ---------- */
const menuWrap = $('#menuWrap'), menuBtn = $('#menuBtn');
const renderers = {};
function route() {
  let r = (location.hash || '#home').slice(1);
  let v = $('#view-' + r);
  if (!v) { v = $('#view-404'); r = '404'; }
  $$('.view').forEach(x => x.hidden = x !== v);
  document.title = v.dataset.title;
  $$('.menu a').forEach(a => a.classList.toggle('active', a.dataset.route === r));
  menuWrap.classList.remove('open'); menuBtn.setAttribute('aria-expanded', 'false');
  window.scrollTo(0, 0); finalizeDue();
  if (renderers[r]) renderers[r]();
  icons();
}
window.addEventListener('hashchange', route);

/* ---------- Home ---------- */
const LOOP = [
  ['Food donor', 'A canteen, restaurant or event team has safe food left over and lists it with a collect-by time.'],
  ['FoodLoop', 'The listing appears on the map and list with diet, allergen and freshness details.'],
  ['Verified recipient', 'An NGO or community kitchen finds a nearby match and slides to claim it.'],
  ['Pickup', 'The recipient gets directions, a pickup code and the coordinator’s phone number.'],
  ['Redistribution', 'The recipient confirms collection and the servings are counted in the impact page.']
];
function setLoop(i) {
  $$('#loopStages button').forEach((b, j) => b.setAttribute('aria-selected', j === i));
  $('#loopCard').innerHTML = `<h3>${LOOP[i][0]}</h3><p>${LOOP[i][1]}</p><p><small>Stop ${i + 1} of ${LOOP.length}. After the last stop the loop starts again.</small></p>`;
}
renderers.home = () => {
  renderFair();
  if (!$('#loopStages').children.length) {
    $('#loopStages').innerHTML = LOOP.map((s, i) => `<button role="tab" type="button" data-loop="${i}">${s[0]}</button>`).join('');
    $$('#loopStages button').forEach((b, i) => { b.onclick = b.onmouseenter = () => setLoop(i); });
    setLoop(0);
  }
  const live = S.listings.filter(l => eff(l) === 'available').sort((a, b) => new Date(a.deadline) - new Date(b.deadline)).slice(0, 5);
  $('#previewTrack').innerHTML = live.map(cardHTML).join('') || '<div class="empty">No food listed right now.</div>';
  $('#homeStats').innerHTML = statsHTML(impact());
  $$('#homeStats [data-count]').forEach(countUp);
};

/* ---------- How ---------- */
renderers.how = () => {
  const steps = [['clipboard-list','List surplus food','A donor adds the food, servings, diet type, allergens and the time it must be collected by.'],
    ['search','Discover a match','Anyone can browse the map and list without an account. Filters narrow by food type, diet and distance.'],
    ['route','Coordinate pickup','Slide to claim, open directions in Google Maps, and call or message the coordinator for gate entry.'],
    ['party-popper','Confirm redistribution','After collecting, the recipient confirms. The servings are added to the impact page.']];
  $('#howList').innerHTML = steps.map((s, i) => `<div><h3>${IC(s[0], 28)} Step ${i + 1}: ${s[1]}</h3><p>${s[2]}</p></div>`).join('');
};

/* ---------- Impact page ---------- */
renderers.impact = () => {
  const i = impact();
  $('#impactStats').innerHTML = statsHTML(i) + extraStats(); $$('#impactStats [data-count]').forEach(countUp);
  $('#dataFlag').textContent = i.sample ? `${i.sample} of ${i.count} completed donations are sample data. Real pickups you complete are added to the totals.` : 'All figures come from pickups completed in this browser.';
  const by = {}; S.done.forEach(d => by[d.cat] = (by[d.cat] || 0) + d.servings);
  const max = Math.max(1, ...Object.values(by));
  $('#impactBars').innerHTML = Object.keys(by).length ? Object.entries(by).map(([c, n]) =>
    `<div class="bar"><span>${c}</span><i style="width:${n / max * 100}%"></i><b>${n}</b></div>`).join('') : '<div class="empty">No completed pickups yet.</div>';
  $('#impactTimeline').innerHTML = S.done.slice(0, 8).map(d =>
    `<li><strong>${esc(d.title)}</strong> – ${d.servings} servings (${d.cat})${d.sample ? ' <span class="badge">Sample</span>' : ''}<br><small>${new Date(d.at).toLocaleString()}</small></li>`).join('');
};

/* ---------- Discover ---------- */
const F = { diet: '', avail: false };
let map, layer, routeLine, firstDiscover = true;
function initMap() {
  if (map) return;
  if (!window.L) { $('#map').innerHTML = '<div class="empty">The map could not load. Check your internet connection. The list still works.</div>'; return; }
  map = L.map('map', { scrollWheelZoom: false }).setView([ORIGIN.lat, ORIGIN.lng], 13);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap contributors' }).addTo(map);
  layer = L.layerGroup().addTo(map);
}
function drawMap(list) {
  if (!map) return;
  layer.clearLayers(); routeLine = null;
  const o = origin();
  L.marker([o.lat, o.lng], { icon: L.divIcon({ className: '', html: '<div class="you-pin">You are here</div>', iconSize: [112, 30], iconAnchor: [56, 15] }), zIndexOffset: 1000 }).addTo(layer);
  const pts = [[o.lat, o.lng]];
  list.forEach(l => {
    const icon = L.divIcon({ className: '', iconSize: [46, 46], iconAnchor: [23, 23],
      html: `<div style="font-size:26px;background:#fff;border:3px solid #183D32;border-radius:50%;width:46px;height:46px;display:grid;place-items:center;box-shadow:0 4px 10px rgba(0,0,0,.25)">${CATS[l.cat] || '🍱'}</div>` });
    const m = L.marker([l.lat, l.lng], { icon, title: l.title }).addTo(layer);
    m.bindPopup(`<strong>${esc(l.title)}</strong><br>${esc(l.org)}<br>${dist(l).toFixed(1)} km • about ${walkMins(l)} min walk<br>
      <button class="btn btn-primary" style="min-height:44px;margin-top:8px;width:100%" data-dir="${l.id}">Get Directions</button>
      <button class="btn btn-ghost" style="min-height:44px;margin-top:6px;width:100%" data-open="${l.id}">View details</button>`);
    m.on('click', () => {
      if (routeLine) layer.removeLayer(routeLine);
      routeLine = L.polyline([[o.lat, o.lng], [l.lat, l.lng]], { color: '#A5502E', weight: 4, dashArray: '8 10' }).addTo(layer);
      map.fitBounds(routeLine.getBounds(), { padding: [60, 60] });
    });
    pts.push([l.lat, l.lng]);
  });
  if (pts.length > 1) map.fitBounds(pts, { padding: [40, 40] });
}
function filtered() {
  const q = $('#fSearch').value.trim().toLowerCase(), cat = $('#fCategory').value, sort = $('#fSort').value, maxD = +$('#fDist').value;
  let a = S.listings.filter(l => eff(l) !== 'cancelled');
  if (q) a = a.filter(l => (l.title + ' ' + l.desc + ' ' + l.org).toLowerCase().includes(q));
  if (cat) a = a.filter(l => l.cat === cat);
  if (F.diet) a = a.filter(l => l.diet === F.diet);
  if (F.avail) a = a.filter(l => eff(l) === 'available');
  if (maxD) a = a.filter(l => dist(l) <= maxD);
  if (sort === 'distance') a.sort((x, y) => dist(x) - dist(y));
  else if (sort === 'quantity') a.sort((x, y) => y.servings - x.servings);
  else a.sort((x, y) => new Date(x.deadline) - new Date(y.deadline));
  return a;
}
function drawList() {
  const a = filtered();
  $('#listState').innerHTML = a.length ? `<p><strong>${a.length}</strong> listing${a.length === 1 ? '' : 's'} found</p>` :
    '<div class="empty"><h3>No food matches these filters</h3><p>Try a wider distance or clear the search.</p></div>';
  $('#listGrid').innerHTML = a.map(cardHTML).join('');
  drawMap(a); icons();
}
renderers.discover = () => {
  initMap();
  if (map) setTimeout(() => map.invalidateSize(), 60);
  if (firstDiscover) {
    firstDiscover = false;
    $('#listGrid').innerHTML = '<div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div>';
    setTimeout(drawList, 350);
  } else drawList();
};
function locate() {
  if (!navigator.geolocation) return toast('Your browser cannot share location.', 'err');
  navigator.geolocation.getCurrentPosition(p => {
    me = { lat: p.coords.latitude, lng: p.coords.longitude };
    $('#locNote').textContent = 'Distances now use your shared location. It stays in this browser.';
    $('#fSort').value = 'distance'; drawList(); updatePill(); toast('Location found.');
  }, () => toast('Could not get your location. Distances use the demo start point.', 'err'), { timeout: 8000 });
}

/* ---------- Drawer ---------- */
let lastFocus = null;
function openDrawer(id) {
  const l = byId(id); if (!l) return;
  curId = id; lastFocus = document.activeElement;
  const st = eff(l), mine = S.my === l.id, v = isVerified(l.org);
  const action = actionHTML(l, st);
  $('#drawerBody').innerHTML = `
    <div class="card-img" style="border-radius:20px;margin-top:20px" aria-hidden="true">${CATS[l.cat] || '🍱'}</div>
    <div class="badges" style="margin-top:14px"><span class="badge"><span class="vd ${l.diet}"></span>${l.diet === 'veg' ? 'Vegetarian' : 'Non-vegetarian'}</span>
      ${l.allergens ? `<span class="badge allergen">${IC('alert-triangle')}Contains: ${esc(l.allergens)}</span>` : '<span class="badge">No allergens listed</span>'}
      <span class="badge ${stCls(st)}">${ST[st]}</span></div>
    <h2 id="drawerTitle" style="margin-top:14px">${esc(l.title)}</h2>
    <div class="fresh ${soon(l) ? 'soon' : ''}">${IC('clock', 18)}<span>${freshText(l)}</span></div>
    <p style="margin-top:12px">${esc(l.desc)}</p>
    <dl><dt>Donor</dt><dd>${esc(l.org)} ${v ? `<span class="badge verified">${IC('shield-check')}Verified</span>` : '<span class="badge">Not yet verified</span>'}</dd>
      <dt>Servings</dt><dd>${remaining(l)} left of ${l.servings}</dd><dt>Price</dt><dd>Verified NGOs: FREE. Individuals: ${l.price ? '₹' + l.price + ' per serving' : 'free'}.</dd><dt>Pickup address</dt><dd>${esc(l.address)}</dd>
      <dt>Distance</dt><dd>${dist(l).toFixed(1)} km, about ${walkMins(l)} min walk${me ? '' : ' (from demo start)'}</dd>
      <dt>Handling</dt><dd>${esc(l.handling || 'None given')}</dd><dt>Pickup needs</dt><dd>Bring your own containers. Show your pickup code.</dd></dl>
    <button class="btn btn-primary btn-lg" data-dir="${l.id}">${IC('navigation', 20)}Get Directions in Google Maps</button>
    <div class="contact-row"><a class="btn btn-ghost" href="tel:${esc(l.phone)}">${IC('phone', 20)}Call coordinator</a>
      <a class="btn btn-ghost" href="sms:${esc(l.phone)}">${IC('message-circle', 20)}Message</a></div>
    ${action}
    <p style="margin-top:20px"><button class="btn btn-ghost" data-act="report" data-id="${l.id}" style="min-height:44px">${IC('flag', 18)}Report this listing</button></p>`;
  $('#drawer').hidden = false; document.body.style.overflow = 'hidden';
  icons(); $('#drawerPanel').focus();
  bindClaim(l);
}
function closeDrawer() {
  if ($('#drawer').hidden) return;
  $('#drawer').hidden = true; document.body.style.overflow = '';
  if (lastFocus && lastFocus.focus) lastFocus.focus();
}
function slider(root, onDone) {
  const k = $('.slider-knob', root), f = $('.slider-fill', root);
  let dx = 0, drag = false;
  const max = () => root.clientWidth - k.offsetWidth - 8;
  const set = x => { k.style.transform = `translateX(${x}px)`; f.style.width = (x + k.offsetWidth) + 'px'; };
  const end = () => {
    if (!drag) return; drag = false;
    k.style.transition = 'transform .3s'; f.style.transition = 'width .3s';
    if (dx >= max() * .9) { set(max()); root.classList.add('done'); $('.slider-label', root).textContent = 'Claimed'; onDone(); }
    else { dx = 0; set(0); }
  };
  k.addEventListener('pointerdown', e => { drag = true; k.setPointerCapture(e.pointerId); k.style.transition = f.style.transition = 'none'; });
  k.addEventListener('pointermove', e => {
    if (!drag) return;
    dx = Math.max(0, Math.min(max(), e.clientX - root.getBoundingClientRect().left - k.offsetWidth / 2 - 4)); set(dx);
  });
  k.addEventListener('pointerup', end); k.addEventListener('pointercancel', end);
  k.addEventListener('keydown', e => { if (['Enter', 'ArrowRight', ' '].includes(e.key)) { e.preventDefault(); drag = true; dx = max(); end(); } });
}

/* ---------- Claim / status flow ---------- */
const qr = seed => { let h = 7; for (const c of seed) h = (h * 31 + c.charCodeAt(0)) >>> 0; let c = '';
  for (let y = 0; y < 11; y++) for (let x = 0; x < 11; x++) { h = (h * 1103515245 + 12345) >>> 0; if ((h >> 16) & 1) c += `<rect x="${x}" y="${y}" width="1" height="1"/>`; }
  return `<svg class="qr" viewBox="0 0 11 11" role="img" aria-label="Demo QR code, not scannable">${c}</svg>`; };
const redraw = () => { if (!$('#drawer').hidden && curId) openDrawer(curId); };
const SIX = ['Identify recipient', 'Verify eligibility', 'Determine priority', 'Allocate food', 'Free pickup or payment', 'Confirm collection'];
const NGOFLOW = ['NGO Registration', 'Document Review', 'Admin Approval', 'Verified NGO Badge', 'Priority Food Allocation', 'Free Pickup'];
const stepper = (a, on) => a.map((x, i) => `<li class="${i < on ? 'done' : i === on ? 'now' : ''}"><b>${i + 1}</b><span>${x}</span></li>`).join('');
const polName = () => S.policy === 'simple' ? 'NGOs first → all individuals first-come-first-served' : 'NGO → verified assistance → general individuals (FCFS in each group)';
function actionHTML(l, st) {
  const a = meAcc(), t = tierOfAcc(a), rs = lres(l).filter(r => r.rs !== 'cancelled');
  const mins = Math.ceil((l.windowEnd - now()) / 6e4);
  const wnd = windowOpen(l) ? `<div class="fresh">${IC('hourglass', 18)}<span><strong>NGO-priority window open: ${mins} min left.</strong> Requests are queued. Verified NGOs can still outrank earlier individual requests. Nothing is final and no payment is possible until the window closes.</span></div>`
    : '<div class="fresh">Priority window closed. Allocations are final; late requests only get servings nobody has been committed to.</div>';
  const who = `<p class="idbox">You are: <strong>${a ? esc(a.name) : 'Guest (general individual)'}</strong> — ${a ? statusLabel(a) : 'not signed in'} — ${t === 1 ? 'Tier 1: NGO priority, FREE' : t === 2 ? 'Tier 2: assistance rate' : 'Tier 3: pays the donor’s price'} <button class="linkbtn" data-role="login">${a ? 'Switch account' : 'Sign in'}</button></p>`;
  const list = rs.length ? `<h3 style="margin-top:20px">Requests for this food</h3><ul class="res-list">${rs.map(r => `<li><strong>${esc(r.who)}</strong> – ${pubType(r)} – ${r.alloc} of ${r.requested} servings<br><small>${RS[r.rs]} • ${PAY[r.pay]}${r.rs !== 'queued' && r.alloc ? ` • ₹${r.amount}` : ''}</small>${r.mine && r.code && r.rs === 'confirmed' ? `<br>Pickup code: <strong>${r.code}</strong>` : ''}<div>${rAct(r)}</div></li>`).join('')}</ul>` : '';
  const open = st === 'available';
  const form = open ? `${who}<div class="claim-box"><p><small>Active policy: ${polName()}. Proposed FoodLoop policy, not a government poverty determination.</small></p>
    <label class="field"><span>Servings you need</span><input id="cQty" type="number" min="1" value="1"></label>
    <div class="slider" id="claimSlider"><div class="slider-fill"></div><div class="slider-label">Slide to request</div><button class="slider-knob" type="button" aria-label="Slide right or press Enter to request this food">${IC('chevrons-right', 24)}</button></div></div>`
    : `${who}<p><span class="badge ${stCls(st)}">${ST[st]}</span>${st === 'allocated' ? ' All servings are committed.' : ''}</p>`;
  return `<ol class="flow mini">${stepper(SIX, windowOpen(l) ? 2 : 3)}</ol>${wnd}${form}${list}`;
}
function bindClaim(l) { const sl = $('#claimSlider'); if (sl) slider(sl, () => doClaim(l)); }
function doClaim(l) {
  const out = createRequest(l.id, S.session, $('#cQty').value);
  if (!out.ok) { toast(out.msg, 'err'); return openDrawer(l.id); }
  updatePill(); refresh(); openDrawer(l.id);
  toast(out.res.rs === 'queued' ? 'Request queued. Allocation is final when the priority window closes.' : out.res.pay === 'pending' ? 'Allocated! Payment is now open.' : 'Food successfully claimed! FREE — no payment required.');
}
function openPay(rid) {
  const r = S.res.find(x => x.id === rid); if (!r) return;
  const l = byId(r.lid), m = $('#payModal'), done = () => { m.hidden = true; updatePill(); refresh(); redraw(); };
  if (r.rs !== 'allocated' || !(r.amount > 0)) { toast('Payment is available only after allocation is final and an amount is due.', 'err'); return; }
  const orig = r.alloc * l.price, disc = orig - r.amount;
  const SUB = { UPI: ['Google Pay', 'PhonePe', 'Paytm', 'Other UPI app'], Card: ['Demo debit card', 'Demo credit card'], Netbanking: ['Demo Bank A', 'Demo Bank B'], Wallet: ['Demo Wallet'] };
  $('#payCard').innerHTML = `<p class="demo-banner">DEMO PAYMENT — NO REAL MONEY WILL BE CHARGED</p><h2 id="payTitle">Checkout</h2>
    <dl><dt>Food</dt><dd>${esc(l.title)}</dd><dt>Recipient type</dt><dd>${pubType(r, true)}</dd><dt>Approved</dt><dd>${r.alloc} servings</dd><dt>Price each</dt><dd>₹${l.price}</dd>
    ${disc > 0 ? `<dt>Assistance discount</dt><dd>− ₹${disc}</dd>` : ''}<dt>Final payable</dt><dd><strong>₹${r.amount}</strong></dd></dl>
    <fieldset class="field"><legend>Payment method (simulated)</legend>${Object.keys(SUB).map((k, i) => `<label class="radio"><input type="radio" name="pm" value="${k}" ${i ? '' : 'checked'}>${k === 'Netbanking' ? 'Net Banking' : k === 'Card' ? 'Debit / Credit Card' : k}</label>`).join('')}</fieldset>
    <label class="field"><span>Option</span><select id="pSub"></select></label><div id="pQr">${qr(r.id)}<p><small>Fictional demo QR. Never enter real UPI PINs, card numbers or CVV.</small></p></div>
    <label class="field"><span>Demo outcome</span><select id="payOutcome"><option value="success">Success</option><option value="fail">Failure</option></select></label>
    <button class="btn btn-primary btn-lg" id="payGo" type="button">Simulate Payment</button><button class="btn btn-ghost" id="payCancel" type="button" style="margin-top:10px;width:100%">Cancel reservation</button>`;
  const fill = () => { const k = $('input[name=pm]:checked').value; $('#pSub').innerHTML = SUB[k].map(x => `<option>${x}</option>`).join(''); $('#pQr').hidden = k !== 'UPI'; };
  $$('input[name=pm]').forEach(x => x.onchange = fill); fill();
  m.hidden = false; $('#payGo').focus();
  $('#payCancel').onclick = () => { cancelRes(rid); toast('Reservation cancelled. Servings released.'); done(); };
  $('#payGo').onclick = () => {
    const out = payRes(rid, $('input[name=pm]:checked').value, $('#payOutcome').value, $('#pSub').value);
    $('#payCard').innerHTML = `<p class="demo-banner">DEMO PAYMENT — NO REAL MONEY WAS CHARGED</p>` + (out.ok
      ? `<h2>Payment successful (simulated)</h2><dl><dt>Order ID</dt><dd>${out.order}</dd><dt>Receipt</dt><dd>₹${out.amount} for ${out.res.alloc} × ${esc(l.title)}</dd><dt>Method</dt><dd>${esc($('#pSub') ? '' : '')}${esc(S.pay[0].method)} – ${esc(S.pay[0].sub)}</dd><dt>Pickup code</dt><dd><strong>${out.res.code}</strong></dd></dl>`
      : `<h2>${out.res ? 'Payment failed (simulated)' : 'Payment not available'}</h2><p>${esc(out.msg || 'You were not charged. Your allocation is still held; try again or cancel.')}</p>`) + '<button class="btn btn-primary" id="payDone" type="button">Close</button>';
    $('#payDone').onclick = done; $('#payDone').focus(); toast(out.ok ? 'Demo payment successful. Pickup code issued.' : 'Demo payment failed. You were not charged.', out.ok ? 'ok' : 'err');
  };
}
function doCollect(rid) {
  const out = collectRes(rid); if (!out.ok) return toast(out.msg, 'err');
  updatePill(); refresh(); redraw(); celebrate({ servings: out.res.alloc, title: out.l.title, org: out.l.org });
}
/* ---------- Account UI ---------- */
const FLD = (id, l, t = 'text', h = '', req = true) => `<label class="field"><span>${l}${req ? '' : ' (optional)'}</span><input id="f_${id}" type="${t}" autocomplete="off">${h ? `<small>${h}</small>` : ''}<small class="err" id="e_${id}"></small></label>`;
function acctChip() { const a = meAcc(); $('#acct').textContent = a ? `${a.name.split(' (')[0]} • ${statusLabel(a)}` : 'Sign in'; }
function openAuth(mode) {
  const c = $('#authCard'), banner = '<p class="demo-banner">CLASSROOM DEMO — use fictional details only. Verification is simulated in your browser.</p>';
  const bar = `<button class="drawer-close" id="authX" aria-label="Close">${IC('x')}</button>`;
  if (mode === 'login') c.innerHTML = `${bar}${banner}<h2 id="authTitle">Sign in</h2>${FLD('email', 'Email', 'email')}${FLD('pw', 'Password', 'password', 'Forgot password? Demo only: password reset needs a server and email service, which this prototype does not have.')}
    <button class="btn btn-primary btn-lg" id="authGo">Log in</button><p><small>Demo logins (fictional): admin@foodloop.demo / Admin@1234 • ngo@annadaan.demo (verified), hope@hopekitchen.demo (pending), shelter@oldtrust.demo (rejected), asha@demo.test (assistance), ravi@demo.test (individual): Demo@1234</small></p>
    ${meAcc() ? '<button class="btn btn-ghost" id="authOut">Log out</button>' : ''}<p>New here? <button class="linkbtn" data-role="ngo">Register an NGO</button> • <button class="linkbtn" data-role="assist">Request assistance</button> • <button class="linkbtn" data-role="general">Join as individual</button></p>`;
  else if (mode === 'ngo') c.innerHTML = `${bar}${banner}<h2 id="authTitle">Register your NGO</h2><ol class="flow mini">${stepper(NGOFLOW, 0)}</ol><p>No Aadhaar or personal government ID is needed. Priority is enabled only after admin approval.</p>
    ${FLD('name', 'NGO organisation name')}${FLD('email', 'Official email', 'email')}${FLD('pw', 'Password', 'password', 'Min 8 characters. Kept in memory only.')}${FLD('pw2', 'Confirm password', 'password')}${FLD('contact', 'Contact person’s name')}${FLD('phone', 'Contact number', 'tel')}${FLD('address', 'Organisation address')}
    ${FLD('regNo', 'NGO registration / certificate number', 'text', 'Fictional demo value, e.g. DEMO-REG-4004')}${FLD('darpan', 'NGO Darpan ID', 'text', 'e.g. DL/2020/0123456', false)}${FLD('pan', 'Organisation PAN', 'text', 'Organisation PAN only, fictional', false)}
    <label class="check"><input type="checkbox" id="f_gst"> Our NGO is GST-registered</label><div id="gstBox" hidden>${FLD('gstin', 'GSTIN')}</div>
    <label class="check"><input type="checkbox" id="f_cert"> Attach demo registration certificate (simulated, no file leaves your browser)</label><small class="err" id="e_cert"></small>
    <button class="btn btn-primary btn-lg" id="authGo">Submit for Admin Verification</button>`;
  else c.innerHTML = `${bar}${banner}<h2 id="authTitle">${mode === 'assist' ? 'Request food assistance' : 'Join as an individual'}</h2>
    <p>${mode === 'assist' ? 'No Aadhaar, PAN or income certificate is required. An admin reviews assistance status privately; it is never shown publicly. A real service would need a privacy-compliant, legally reviewed process and a secure backend.' : 'Browsing needs no account. Signing in lets you request food and pay the donor’s affordable price after allocation.'}</p>
    ${FLD('name', 'Full or display name')}${FLD('email', 'Email (or leave blank and use phone)', 'email', '', false)}${FLD('phone', 'Mobile (if no email)', 'tel', '', false)}${FLD('pw', 'Password', 'password', 'Min 8 characters. Kept in memory only.')}${FLD('pw2', 'Confirm password', 'password')}${FLD('city', 'City / area')}
    ${mode === 'assist' ? `${FLD('family', 'Family members', 'number', '', false)}<label class="check"><input type="checkbox" id="f_note"> I would like to be reviewed for assistance (self-declaration, optional)</label>` : ''}
    <button class="btn btn-primary btn-lg" id="authGo">${mode === 'assist' ? 'Request assistance verification' : 'Create account'}</button>`;
  $('#authModal').hidden = false; icons(); const first = $('input', c); if (first) first.focus();
  $('#authX').onclick = () => $('#authModal').hidden = true;
  const g = $('#f_gst'); if (g) g.onchange = () => $('#gstBox').hidden = !g.checked;
  const out = $('#authOut'); if (out) out.onclick = () => { S.session = null; save(); acctChip(); $('#authModal').hidden = true; toast('Logged out.'); refresh(); };
  $('#authGo').onclick = () => {
    const v = {}; $$('input', c).forEach(i => { if (i.id.startsWith('f_')) v[i.id.slice(2)] = i.type === 'checkbox' ? i.checked : i.value.trim(); });
    $$('.err', c).forEach(x => x.textContent = '');
    if (mode === 'login') { const r = login(v.email, v.pw); if (!r.ok) { $('#e_pw').textContent = r.msg; return; } $('#authModal').hidden = true; acctChip(); toast(`Signed in: ${statusLabel(r.acc)}.`); refresh(); redraw(); return; }
    const r = register(mode, v);
    if (!r.ok) { Object.entries(r.errors).forEach(([k, m]) => { const e = $('#e_' + k); if (e) e.textContent = m; }); toast('Please fix the highlighted fields.', 'err'); return; }
    acctChip(); refresh();
    c.innerHTML = `${bar}<h2 id="authTitle">${mode === 'ngo' ? 'NGO Application Submitted — Verification Pending.' : mode === 'assist' ? 'Assistance review requested.' : 'Welcome to FoodLoop!'}</h2>
      ${mode === 'ngo' ? `<ol class="flow mini">${stepper(NGOFLOW, 1)}</ol><p>You stay <strong>Verification Pending</strong> until the demo admin approves you. Signing in alone never grants verified status.</p>` : mode === 'assist' ? '<p>Status: <strong>Pending</strong>. Until an admin verifies you, you are treated as a general individual. Your status is visible only to you and the admin.</p>' : '<p>You can now request food.</p>'}
      <a class="btn btn-primary" href="#discover" id="authGoD">Find food</a>`;
    $('#authX').onclick = $('#authGoD').onclick = () => $('#authModal').hidden = true;
  };
}
/* ---------- Teacher demos: run the REAL allocation engine ---------- */
const sleep = ms => new Promise(r => setTimeout(r, matchMedia('(prefers-reduced-motion:reduce)').matches ? 0 : ms));
function bars(res, total, why) { return `<div class="bars">${res.map(x => `<div class="bar"><span>${esc(x.r.n)}</span><i style="width:${x.a / total * 100}%"></i><b>${x.a}</b></div><p class="why">${esc(why(x))}</p>`).join('')}</div>`; }
async function demo1() {
  const out = $('#demoOut'), P = [{ n: 'Person A', t: '10:01 AM', requested: 15, tier: 3, ts: 1 }, { n: 'Person B', t: '10:02 AM', requested: 10, tier: 3, ts: 2 }, { n: 'Verified NGO', t: '10:05 AM', requested: 30, tier: 1, ts: 5 }, { n: 'Person C', t: '10:06 AM', requested: 10, tier: 3, ts: 6 }];
  let h = '<h3>50 meals donated. NGO-priority window is open.</h3><ol class="tl">'; out.innerHTML = h + '</ol>';
  for (const p of P) { h += `<li><b>${p.t}</b> ${p.n} requests ${p.requested} meals${p.tier === 1 ? ' <span class="badge verified">Verified NGO</span> (arrived 3rd, nothing is final yet)' : ''}</li>`; out.innerHTML = h + '</ol>'; await sleep(650); }
  h += '</ol><p><strong>Window closes → allocation is finalised.</strong></p>'; out.innerHTML = h; await sleep(500);
  const res = allocateQueue(50, 0, P, 'fair3'), tot = res.reduce((a, x) => a + x.a, 0); let k = 0;
  out.innerHTML = h + bars(res, 50, x => x.r.tier === 1 ? 'Priority 1: verified NGO served first and FREE (₹0), despite requesting third.' : (k++, x.a === 0 ? 'Waitlisted: nothing left after the NGO and earlier requests.' : x.a < x.r.requested ? `Partially allocated: only ${x.a} of ${x.r.requested} remained.` : `First come, first served among individuals (#${k}).`)) + `<p class="total">Total allocated: <strong>${tot} of 50</strong>. Then: NGO pays ₹0; individuals pay only for their final allocation.</p>`;
}
function demo2() {
  const R = [{ n: 'Ordinary buyer', requested: 20, tier: 3, ts: 1, t: '10:01 AM' }, { n: 'Verified assistance recipient', requested: 20, tier: 2, ts: 3, t: '10:03 AM' }];
  const col = (pol, title) => { const r = allocateQueue(30, 0, R, pol); return `<div class="panel"><h3>${title}</h3>${bars(r, 30, x => x.r.tier === 2 ? (pol === 'fair3' ? 'Tier 2: assistance verified by admin, served before general buyers. Pays the assistance rate (₹0 in this demo).' : 'Simple policy: no assistance tier; ordered by arrival time.') : (pol === 'fair3' ? 'Tier 3: general buyers get the remainder at the donor’s price (₹5 each).' : 'Arrived first, so served first; pays ₹5 each.'))}</div>`; };
  $('#demoOut').innerHTML = '<h3>30 meals. Buyer asks at 10:01, verified assistance recipient asks at 10:03.</h3><div class="two">' + col('fair3', 'Policy: NGO → assistance → general') + col('simple', 'Policy: NGOs first → everyone FCFS') + '</div><p>Verification and the active policy, not wealth or speed, decide who is served first. Proposed FoodLoop policy, not a government poverty determination.</p>';
}
function renderFair() {
  $('#roleCards').innerHTML = [['ngo', '🏛️', 'I Represent an NGO', ['NGO registration & document review', 'Admin verification', 'NGO login', 'Verified priority access', 'Free food allocation'], 'Register my NGO'],
    ['assist', '🤝', 'I Need Food Assistance', ['Simple registration, no ID uploads', 'Optional private eligibility review', 'Priority after NGOs once verified', 'Free or subsidised food', 'Respectful and private'], 'Request assistance'],
    ['general', '🙋', 'I Am a General Individual', ['Login or register', 'Browse all surplus food', 'First-come-first-served', 'Affordable purchase after allocation'], 'Join as individual']]
    .map(([r, e, t, li, b]) => `<article class="role-card rc-${r}"><span class="rc-ic" aria-hidden="true">${e}</span><h3>${t}</h3><ul>${li.map(x => `<li>${x}</li>`).join('')}</ul><button class="btn btn-light" data-role="${r}">${b}</button></article>`).join('');
  $('#policyNote').innerHTML = `<strong>Active allocation policy:</strong> ${polName()}. <em>FoodLoop’s configurable proposed policy, not a government poverty determination.</em>`;
  $('#flowSix').innerHTML = stepper(SIX, 6); $('#flowNgo').innerHTML = stepper(NGOFLOW, 6);
  $('#duo').innerHTML = `<article class="feature fa"><h2>Verified People. Fair Food Distribution.</h2><ul><li>NGO verification by admin</li><li>Private assistance verification</li><li>Admin-approved status only</li><li>NGO-first priority window</li><li>First-come-first-served inside every group</li><li>Allocation explained in plain words</li></ul><a class="btn btn-light" href="#demo">Run the teacher demo</a></article>
    <article class="feature fb"><h2>First We Allocate Fairly. Then You Pay Only If Required.</h2><ul><li>Verified NGO: ₹0, free pickup</li><li>Assistance: free or subsidised</li><li>General individuals: affordable checkout</li><li>UPI • Card • Net Banking • Wallet (simulated)</li><li>Payment opens only after allocation</li><li>Receipt and pickup code</li></ul><a class="btn btn-terra" href="#discover">Try checkout</a></article>`;
  $('#demo').innerHTML = `<h2>See How FoodLoop Gives Food Fairly</h2><p class="sub">These buttons run the real allocation engine used by the site.</p><div class="cta-row"><button class="btn btn-primary" id="runDemo1">Run the 50-Meal Priority Demo</button><button class="btn btn-ghost" id="runDemo2">Verified Needy Recipient vs Ordinary Buyer</button></div><div id="demoOut" aria-live="polite"></div>`;
  $('#runDemo1').onclick = demo1; $('#runDemo2').onclick = demo2;
}
function celebrate(l) {
  $('#celTitle').textContent = `You just fed ${l.servings} ${l.servings === 1 ? 'person' : 'people'} today.`;
  $('#celText').textContent = `“${l.title}” from ${l.org} found a destination instead of the bin. Thank you for closing the loop.`;
  const c = $('#celebrate'); c.hidden = true; void c.offsetWidth; c.hidden = false; $('#celClose').focus();
}
function activeRes() { return S.res.find(r => r.mine && ['queued', 'allocated', 'confirmed'].includes(r.rs) && r.pickup !== 'collected'); }
function updatePill() {
  const r = activeRes(), l = r && byId(r.lid);
  if (!l) { $('#pill').hidden = true; return; }
  $('#pill').hidden = false;
  $('#pillTitle').textContent = r.rs === 'confirmed' ? `Walk to ${l.org} • ${walkMins(l)} min away` : r.rs === 'queued' ? `Queued: ${l.title}` : `Payment due: ${l.title}`;
  $('#pillSub').textContent = r.rs === 'confirmed' ? `Show code: ${r.code}` : r.rs === 'queued' ? 'Waiting for the priority window to close' : `₹${r.amount} (demo)`;
}
function refresh() {
  const r = (location.hash || '#home').slice(1);
  if (r === 'discover') drawList(); else if (r === 'dash') renderers.dash(); else if (r === 'home') renderers.home();
  icons();
}

/* ---------- Dashboards ---------- */
let tab = 'donor';
const table = (head, rows) => `<div class="table-wrap"><table><thead><tr>${head.map(h => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rows}</tbody></table></div>`;
renderers.dash = () => {
  $$('.tab').forEach(t => { t.classList.toggle('on', t.dataset.tab === tab); t.setAttribute('aria-selected', t.dataset.tab === tab); });
  const b = $('#dashBody'), ls = S.listings.filter(l => l.status !== 'cancelled'), me = meAcc();
  const sum = (l, f) => lres(l).filter(f).reduce((a, r) => a + r.alloc, 0), act = r => ['allocated', 'confirmed'].includes(r.rs);
  const paid = S.pay.filter(p => p.status === 'successful').reduce((a, p) => a + p.amount, 0);
  const ver = a => `<span class="badge ${a.status === 'verified' ? 'status-available' : a.status === 'pending' ? 'status-pending' : 'status-bad'}">${statusLabel(a)}</span>`;
  const btns = a => a.status === 'pending' ? `<button class="btn btn-primary" data-act="approve" data-id="${a.id}">Approve</button><button class="btn btn-ghost" data-act="reject" data-id="${a.id}">Reject</button>` : '–';
  if (tab === 'donor') {
    b.innerHTML = `<div class="stat-row">${[['Active listings', ls.filter(l => eff(l) === 'available').length], ['Servings uncommitted', ls.reduce((a, l) => a + (eff(l) === 'available' ? remaining(l) : 0), 0)],
      ['Servings collected', S.res.filter(r => r.pickup === 'collected').reduce((a, r) => a + r.alloc, 0)], ['Paid (simulated)', '₹' + paid]].map(([k, n]) => `<div class="stat"><b>${n}</b><span>${k}</span></div>`).join('')}</div>
      <div class="panel"><h2>Your listings</h2><p><small>Verified NGOs: free. Assistance recipients: ₹ assistance rate. General individuals: your price. Demo payments only.</small></p>${table(['Food', 'Total', 'NGO (free)', 'Assistance', 'General', 'Left', 'Price', 'Window', ''], ls.map(l => {
        const s = eff(l);
        return `<tr><td><strong>${esc(l.title)}</strong><br><small>${esc(l.org)}</small></td><td>${l.servings}</td><td>${sum(l, r => act(r) && r.tier === 1)}</td><td>${sum(l, r => act(r) && r.tier === 2)}</td><td>${sum(l, r => act(r) && r.tier === 3)}</td><td>${remaining(l)}</td><td>₹${l.price} / ₹${l.assistPrice}</td>
          <td>${windowOpen(l) ? 'Open' : 'Closed'}</td><td>${['available', 'allocated'].includes(s) ? `<button class="btn btn-ghost" data-act="cancel" data-id="${l.id}">Cancel listing</button>` : `<span class="badge ${stCls(s)}">${ST[s]}</span>`}</td></tr>`; }).join(''))}
      <p><a class="btn btn-terra" href="#donate">Post a new listing</a></p></div><div class="panel"><h2>Who claimed your food</h2>${table(RH(true), resRows(S.res, true, false))}</div>`;
  } else if (tab === 'recipient') {
    const mine = S.res.filter(r => r.mine), ids = mine.map(r => r.id), pays = S.pay.filter(p => ids.includes(p.rid));
    b.innerHTML = `<div class="panel"><h2>${me ? esc(me.name) : 'Guest'}</h2><p>${me ? statusLabel(me) : 'Not signed in. You can request food as a guest general individual.'} <button class="btn btn-ghost" data-role="login" style="min-height:44px">${me ? 'Switch account' : 'Sign in'}</button></p></div>
      <ol class="flow">${stepper(SIX, mine.some(r => r.pickup === 'collected') ? 6 : mine.some(r => r.rs === 'confirmed') ? 5 : mine.some(r => r.rs === 'allocated') ? 4 : mine.length ? 3 : 0)}</ol>
      <div class="panel"><h2>My reservations</h2>${table(RH(true), resRows(mine, true, false))}</div>
      <div class="panel"><h2>My transactions (demo)</h2>${table(['Order', 'Amount', 'Method', 'Status', 'Time'], pays.map(p => `<tr><td>${p.order}</td><td>₹${p.amount}</td><td>${esc(p.method)} ${esc(p.sub)}</td><td>${p.status} (demo)</td><td>${new Date(p.ts).toLocaleString()}</td></tr>`).join('') || '<tr><td colspan="5">None yet.</td></tr>')}</div>
      <div class="panel"><h2>Collection history</h2>${S.done.slice(0, 6).map(d => `<p>${esc(d.title)} – ${d.servings} servings${d.sample ? ' <span class="badge">Sample</span>' : ''}</p>`).join('')}</div>`;
  } else if (!me || me.role !== 'admin') {
    b.innerHTML = '<div class="panel"><h2>FoodLoop Admin — Verification &amp; Fair Allocation</h2><p class="demo-banner">DEMO ADMIN MODE — client-side login is NOT secure</p><p>Sign in with the fictional demo admin account to review NGOs and assistance applications.</p><button class="btn btn-primary" data-role="login">Demo admin login</button></div>';
  } else {
    const ng = S.acc.filter(a => a.role === 'ngo'), as = S.acc.filter(a => a.role === 'assist'), q = S.res.filter(r => ['queued', 'allocated'].includes(r.rs));
    b.innerHTML = `<div class="panel"><h2>FoodLoop Admin — Verification &amp; Fair Allocation</h2><p class="demo-banner">DEMO ADMIN MODE — simulated approvals; client-side login is NOT secure</p>
      <div class="filters"><label class="field"><span>Allocation policy</span><select id="polSel"><option value="fair3" ${S.policy === 'fair3' ? 'selected' : ''}>NGO → assistance → general (FCFS in each)</option><option value="simple" ${S.policy === 'simple' ? 'selected' : ''}>NGOs first → all individuals FCFS</option></select></label>
      <div><strong>Demo clock:</strong> ${new Date(now()).toLocaleTimeString()}<br><button class="btn btn-ghost" data-act="adv" data-min="10">+10 min</button><button class="btn btn-primary" data-act="adv" data-min="30">Advance 30 min (close windows)</button></div></div></div>
      <div class="panel"><h2>NGO applications</h2>${table(['NGO', 'Email', 'Registration ID', 'Tax details (optional)', 'Status', 'Actions'], ng.map(a => `<tr><td><strong>${esc(a.name)}</strong></td><td>${esc(a.email)}</td><td>${esc(a.regNo || '–')}</td><td><small>Darpan ${esc(a.darpan || '–')}<br>PAN ${esc(a.pan || '–')}<br>GSTIN ${esc(a.gstin || 'n/a')}</small></td><td>${ver(a)}</td><td>${btns(a)} <button class="btn btn-ghost" data-act="view" data-id="${a.id}">Summary</button></td></tr>`).join(''))}</div>
      <div class="panel"><h2>Assistance applications</h2>${table(['Applicant', 'Submitted', 'Status', 'Actions'], as.map(a => `<tr><td>${esc(a.name)}</td><td>${new Date(a.submittedAt).toLocaleString()}</td><td>${ver(a)}</td><td>${btns(a)}</td></tr>`).join(''))}</div>
      <div class="panel"><h2>Verified lists</h2><p><strong>NGOs:</strong> ${ng.filter(a => a.status === 'verified').map(a => esc(a.name)).join(', ') || 'none'}</p><p><strong>Assistance accounts:</strong> ${as.filter(a => a.status === 'verified').length}</p></div>
      <div class="panel"><h2>Priority queue and allocations</h2>${table(RH(true), resRows(q.sort((x, y) => curTier(x) - curTier(y) || x.ts - y.ts), true, true))}</div>
      <div class="panel"><h2>Payment and refund history (demo)</h2>${table(['Order', 'Amount', 'Method', 'Status', 'Time'], S.pay.map(p => `<tr><td>${p.order || p.id}</td><td>₹${p.amount}</td><td>${esc(p.method)} ${esc(p.sub || '')}</td><td>${p.status} (demo)</td><td>${new Date(p.ts).toLocaleString()}</td></tr>`).join('') || '<tr><td colspan="5">No payments yet.</td></tr>')}</div>
      <div class="panel"><h2>Allocation and audit log</h2><ul class="timeline">${S.log.slice(0, 10).map(e => `<li>${esc(e.m)}<br><small>${new Date(e.t).toLocaleString()}</small></li>`).join('')}</ul><p><button class="btn btn-ghost" data-act="reset">Reset demo data</button></p></div>`;
    const ps = $('#polSel'); if (ps) ps.onchange = () => { S.policy = ps.value; S.listings.forEach(provisional); save(); toast('Policy updated.'); refresh(); };
  }
  icons();
};

/* ---------- Donate form ---------- */
let posting = false;
renderers.donate = () => {
  const sel = $('#dCategory');
  if (!sel.options.length) sel.innerHTML = '<option value="">Choose a category</option>' + Object.keys(CATS).map(c => `<option>${c}</option>`).join('');
};
async function geocode(addr) {
  try {
    const c = new AbortController(); setTimeout(() => c.abort(), 4000);
    const r = await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&q=' + encodeURIComponent(addr), { signal: c.signal });
    const j = await r.json();
    if (j[0]) return { lat: +j[0].lat, lng: +j[0].lon, exact: true };
  } catch (e) { /* fall through */ }
  return { lat: ORIGIN.lat + (Math.random() - .5) * .02, lng: ORIGIN.lng + (Math.random() - .5) * .02, exact: false };
}
function todayAt(hhmm) { const [h, m] = hhmm.split(':').map(Number), d = new Date(); d.setHours(h, m, 0, 0); return d; }
function validate() {
  const v = id => $('#' + id).value.trim(), e = {};
  if (v('dTitle').length < 3) e.dTitle = 'Enter the name of the food.';
  if (!v('dCategory')) e.dCategory = 'Choose a category.';
  const n = +v('dServings'); if (!(n >= 1 && n <= 2000)) e.dServings = 'Enter servings between 1 and 2000.';
  if (!v('dMade')) e.dMade = 'Enter the time it was made.';
  if (!v('dDeadline')) e.dDeadline = 'Enter the collect-before time.';
  if (v('dMade') && v('dDeadline')) {
    const made = todayAt(v('dMade')); let dl = todayAt(v('dDeadline'));
    if (dl <= made) dl = new Date(dl.getTime() + 864e5);
    if (dl <= new Date()) e.dDeadline = 'That time has already passed.';
  }
  if (v('dCategory') === 'Cooked Meals' && !v('dHandling')) e.dHandling = 'Cooked food needs a handling note, for example “keep hot”.';
  if (!v('dOrg')) e.dOrg = 'Enter your organisation name.';
  if (!/^\d{10}$/.test(v('dPhone').replace(/\s/g, ''))) e.dPhone = 'Enter a 10-digit phone number.';
  if (v('dAddress').length < 8) e.dAddress = 'Enter the full pickup address.';
  if (v('dPrice') === '' || !(+v('dPrice') >= 0 && +v('dPrice') <= 100)) e.dPrice = 'Enter a price between ₹0 and ₹100 (0 = free for everyone).';
  if (!$('#dSafe').checked) e.dSafe = 'Please confirm the food is safe to eat.';
  return e;
}
$('#donateForm').addEventListener('submit', async ev => {
  ev.preventDefault(); if (posting) return;
  const errs = validate();
  $$('.err', $('#donateForm')).forEach(x => { x.textContent = errs[x.dataset.for] || ''; const f = x.previousElementSibling; });
  $$('#donateForm .field').forEach(f => f.classList.toggle('invalid', !!$('input,select,textarea', f) && !!errs[$('input,select,textarea', f).id]));
  const first = Object.keys(errs)[0];
  if (first) { $('#' + first).focus(); return toast('Please fix the highlighted fields.', 'err'); }
  posting = true; const btn = $('#dSubmit'); btn.disabled = true; btn.textContent = 'Posting…';
  const v = id => $('#' + id).value.trim();
  const g = await geocode(v('dAddress'));
  const made = todayAt(v('dMade')); let dl = todayAt(v('dDeadline')); if (dl <= made) dl = new Date(dl.getTime() + 864e5);
  const l = { id: 'l' + Date.now(), title: v('dTitle'), cat: v('dCategory'), diet: $('input[name=dDiet]:checked').value, servings: +v('dServings'),
    allergens: v('dAllergens'), org: v('dOrg'), made: made.toISOString(), deadline: dl.toISOString(), lat: g.lat, lng: g.lng, address: v('dAddress'),
    handling: v('dHandling'), desc: v('dDesc') || 'No description given.', phone: v('dPhone').replace(/\s/g, ''), price: +v('dPrice'), assistPrice: 0, windowEnd: now() + S.windowMin * 6e4, status: 'available', code: null, sample: false };
  S.listings.unshift(l); log(`New listing posted: “${l.title}” by ${l.org}`); save();
  posting = false; btn.disabled = false; btn.textContent = 'Post my listing';
  $('#donateForm').reset();
  toast('Listing posted! It is now live on the map.');
  if (!g.exact) setTimeout(() => toast('We could not find that address, so the pin is approximate.', 'err'), 600);
  location.hash = '#discover';
});

/* ---------- Global events ---------- */
document.addEventListener('click', e => {
  const t = e.target.closest('[data-open],[data-dir],[data-act],[data-close],[data-role]');
  if (!t) { if (!e.target.closest('#menuWrap')) menuWrap.classList.remove('open'); if (e.target.id === 'drawer') closeDrawer(); return; }
  if (t.dataset.close !== undefined) closeDrawer();
  if (t.dataset.open) openDrawer(t.dataset.open);
  if (t.dataset.dir) { const l = byId(t.dataset.dir); if (l) window.open(dirURL(l), '_blank', 'noopener'); }
  const a = t.dataset.act, id = t.dataset.id, l = id && byId(id);
  if (a === 'cancel' && l && confirm(`Cancel the listing “${l.title}”? Open reservations are cancelled and any demo payments refunded.`)) {
    lres(l).forEach(r => cancelRes(r.id)); l.status = 'cancelled'; log(`Listing cancelled: “${l.title}”`); save(); updatePill(); toast('Listing cancelled.'); refresh(); }
  const rid = t.dataset.rid;
  if (a === 'pay' && rid) openPay(rid);
  if (a === 'rcancel' && rid && confirm('Cancel this reservation? The servings go back to the listing.')) { cancelRes(rid); toast('Reservation cancelled. Servings released.'); updatePill(); refresh(); redraw(); }
  if (a === 'collect' && rid) doCollect(rid);
  if (a === 'report') toast('Thanks. The listing has been flagged for admin review (simulated).');
  if (a === 'approve' || a === 'reject') { if (review(id, a === 'approve' ? 'verified' : 'rejected')) { toast(`Application ${a === 'approve' ? 'approved' : 'rejected'} (simulated).`); acctChip(); refresh(); } else toast('Demo admin login required.', 'err'); }
  if (a === 'view') { const x = S.acc.find(o => o.id === id); if (x) alert(`${x.name}\n${x.email}\nReg: ${x.regNo || '-'}\nDarpan: ${x.darpan || '-'}  PAN: ${x.pan || '-'}  GSTIN: ${x.gstin || 'n/a'}\nContact: ${x.contact || '-'} ${x.phone || ''}\n${x.address || ''}\n(Fictional demo data)`); }
  if (a === 'adv') { advanceTime(+t.dataset.min); toast('Demo time advanced. Priority windows that ended are now finalised.'); updatePill(); refresh(); }
  if (t.dataset.role) openAuth(t.dataset.role);
  if (a === 'reset' && confirm('Reset all demo data in this browser?')) { localStorage.removeItem(KEY); location.reload(); }
});
document.addEventListener('keydown', e => {
  if (e.key !== 'Escape') return;
  closeDrawer(); $('#payModal').hidden = true; $('#authModal').hidden = true; $('#celebrate').hidden = true; menuWrap.classList.remove('open'); menuBtn.setAttribute('aria-expanded', 'false');
});
menuBtn.addEventListener('click', () => {
  if (matchMedia('(hover:none)').matches) { const o = menuWrap.classList.toggle('open'); menuBtn.setAttribute('aria-expanded', o); }
});
menuWrap.addEventListener('mouseenter', () => menuBtn.setAttribute('aria-expanded', 'true'));
menuWrap.addEventListener('mouseleave', () => menuBtn.setAttribute('aria-expanded', 'false'));
$('#drawerClose').onclick = closeDrawer;
$('#celClose').onclick = () => { $('#celebrate').hidden = true; };
$('#pillAction').onclick = () => { const r = activeRes(); if (r) openDrawer(r.lid); };
$('#locateBtn').onclick = locate;
['fSearch', 'fCategory', 'fSort', 'fDist'].forEach(id => $('#' + id).addEventListener('input', drawList));
$$('#fDiet .chip').forEach(c => c.addEventListener('click', () => {
  if (c.dataset.avail) { F.avail = !F.avail; c.classList.toggle('on', F.avail); }
  else { F.diet = c.dataset.diet; $$('#fDiet [data-diet]').forEach(x => x.classList.toggle('on', x === c)); }
  drawList();
}));
$$('.tab').forEach(t => t.addEventListener('click', () => { tab = t.dataset.tab; renderers.dash(); }));

/* Hero parallax (desktop, motion allowed) */
const hero = $('#heroArt');
if (hero && matchMedia('(hover:hover)').matches && !matchMedia('(prefers-reduced-motion:reduce)').matches) {
  hero.addEventListener('mousemove', e => {
    const r = hero.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5;
    $$('[data-depth]', hero).forEach(g => { const d = +g.dataset.depth * 10; g.style.transform = `translate(${-x * d}px,${-y * d}px)`; });
  });
  hero.addEventListener('mouseleave', () => $$('[data-depth]', hero).forEach(g => g.style.transform = ''));
}

/* Init */
$('#fCategory').innerHTML = '<option value="">All food</option>' + Object.keys(CATS).map(c => `<option>${c}</option>`).join('');
migrate(); updatePill(); acctChip(); $('#acct').onclick = () => openAuth('login');
setInterval(() => { if (finalizeDue()) { updatePill(); refresh(); } }, 15000);
route();
window.FoodLoop = { get state() { return S; }, createRequest, payRes, cancelRes, collectRes, remaining, eff, allocateQueue, register, login, review, advanceTime, finalizeDue, tierOfAcc };
})();
